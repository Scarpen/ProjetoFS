package jogoForca;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author Scarpen
 */
public class BancoForca {    
    private String url;
    private Connection conn;
    
    public BancoForca(){
        url = "jdbc:mysql://localhost:3306/jogoforca?zeroDateTimeBehavior=convertToNull";
        
    }
    
    public Connection getConexao(){
        try {
            
              conn = DriverManager.getConnection(url,"root","root");
          
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
    
}
