/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jogoForca;

import Banco.PalavrasDAO;

/**
 *
 * @author Scarpen
 */
public class Jogo {
            PalavrasDAO dao = new PalavrasDAO();
             public void comecarJogo(int id){
                Global.palavra = dao.buscar(id);
                Global.erros = 0;
                Global.palavra2 = "";
                Global.acertos = 0;
                Global.letra = new String[26];
                Global.letra[0] = "a";
                Global.letra[1] = "b";
                Global.letra[2] = "c";
                Global.letra[3] = "d";
                Global.letra[4] = "e";
                Global.letra[5] = "f";
                Global.letra[6] = "g";
                Global.letra[7] = "h";
                Global.letra[8] = "i";
                Global.letra[9] = "j";
                Global.letra[10] = "k";
                Global.letra[11] = "l";
                Global.letra[12] = "m";
                Global.letra[13] = "n";
                Global.letra[14] = "o";
                Global.letra[15] = "p";
                Global.letra[16] = "q";
                Global.letra[17] = "r";
                Global.letra[18] = "s";
                Global.letra[19] = "t";
                Global.letra[20] = "u";
                Global.letra[21] = "v";
                Global.letra[22] = "w";
                Global.letra[23] = "x";
                Global.letra[24] = "y";
                Global.letra[25] = "z";
                
                
            }
    
            public String getPalavra(){
                Global.palavra2 = "";
                Global.acertos = 0;
                boolean c = false;
                for(int i = 0; i < Global.palavra.getTamanho();i++){
                    c = false;
                    String letra = Global.palavra.getPalavra().charAt(i)+"";
                    if(letra.equals(" ") || letra.equals("-")){
                        Global.palavra2 += "\b\b\b\b\b\b\b\b\b\b\b\b"+letra+"\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b";  
                        Global.acertos += 1;
                        
                        c=true;
                            
                        }
                    for (int j = 0; j < 26; j++) {
                        if(Global.letra[j].equals(letra.toUpperCase())){
                        Global.palavra2 += letra;
                        Global.acertos += 1;
                        c= true;
                        }
                    }
                        if(!c){
                        Global.palavra2 += "_";
                        }

                    Global.palavra2 += " ";
                }

         
            return Global.palavra2;

                        
                        
            }
            
            public void tentarletra(int numero){
                if(!(Global.palavra.getPalavra().toLowerCase().contains(Global.letra[numero]))){
                    Global.erros += 1;
                }
                Global.letra[numero] = Global.letra[numero].toUpperCase();

            }
            
            public boolean fimdejogo(){
                getPalavra();
                if(Global.acertos == Global.palavra.getTamanho()){
                    dao.adicionarjogo(Global.palavra, true);
                    return true;
                }else if(Global.erros >= 6){
                    dao.adicionarjogo(Global.palavra, false);
                    return true;
                }
                return false;
                
            }


}
