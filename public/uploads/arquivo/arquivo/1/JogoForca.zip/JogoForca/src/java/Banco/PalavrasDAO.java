package Banco;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import jogoForca.BancoForca;
import jogoForca.Palavra;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Scarpen
 */
public class PalavrasDAO {
    private Connection con;
    private PreparedStatement ps;
    
    public PalavrasDAO(){
        this.con = new BancoForca().getConexao();
    }
    
    public void inserir(String palavra, String dica){
        String sql = "insert into palavras (palavra, dica) values (?, ?)";
    
        try {
            Class.forName("com.mysql.jdbc.Driver");
            ps = con.prepareStatement(sql);
            ps.setString(1, palavra);//System.out.println("2");
            ps.setString(2, dica);//System.out.println("3");
            ps.execute();
            
            ps.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    public ArrayList<Palavra> getLista(){
        String sql = "select * from palavras";
        ArrayList<Palavra> lista = new ArrayList<Palavra>();
        
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Palavra g = new Palavra(
                        rs.getInt("id"),
                        rs.getString("palavra"),
                        rs.getString("dica"),
                        rs.getInt("acertos"),
                        rs.getInt("jogos"));
                lista.add(g);
            }
            
            return lista;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    

    
    public Palavra buscar(int id){
         String sql = "select * from palavras where id = ?";
        ArrayList<Palavra> lista = new ArrayList<Palavra>();
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Palavra g = new Palavra(
                        rs.getInt("id"),
                        rs.getString("palavra"),
                        rs.getString("dica"),
                        rs.getInt("acertos"),
                        rs.getInt("jogos"));
                lista.add(g);
            }
            return lista.get(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    
    
    public void deleta(String palavra){
        String sql = "delete from palavras where nome like ?";
       
        try {
            Class.forName("com.mysql.jdbc.Driver");
            ps = con.prepareStatement(sql);
           ps.setString(1, "%"+palavra+"%");
      		int registros = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public void adicionarjogo(Palavra palavra, boolean vitoria){
        
        
        String sql = "update palavras set acertos = ?, jogos = ? where id = "+ palavra.getId();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            int acertos = palavra.getAcertos();
            int jogos = palavra.getJogos();
            
             ps = con.prepareStatement(sql);
             ps.setInt(2, jogos+ 1);
                if(vitoria){
                       
                       ps.setInt(1, acertos+ 1);
                }else{
                       ps.setInt(1, acertos);
                }
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   
}
