package jogoForca;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Scarpen
 */
public class Palavra {
    int id;
    String palavra;
    String dica;
    int jogos;
    int acertos;

    public Palavra(String p, String d){
        this.palavra = p;
        this.dica = d;
    }
    
    public Palavra(int id, String p, String d, int a, int j){
        this.id = id;
        this.palavra = p;
        this.dica = d;
        this.jogos = j;
        this.acertos = a;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getPalavra() {
        return palavra;
    }

    public void setPalavra(String palavra) {
        this.palavra = palavra;
    }

    public String getDica() {
        return dica;
    }

    public void setDica(String dica) {
        this.dica = dica;
    }

    public int getJogos() {
        return jogos;
    }

    public void setJogos(int jogos) {
        this.jogos = jogos;
    }

    public int getAcertos() {
        return acertos;
    }

    public void setAcertos(int acertos) {
        this.acertos = acertos;
    }
    
    public int getTamanho(){
        return this.palavra.length();
    }
    
    
}
