/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

/**
 *
 * @author thiago
 */
@ManagedBean
@RequestScoped
public class Sudoku {
    int[][] matriz;

    public void setMatriz(int[][] matriz) {
        this.matriz = matriz;
    }
    int tamanho;
    int ColCount;
    public int getTamanho() {
        prepararProblema();
        tamanho = 3;
        return tamanho*tamanho;
    }
    
    public int getColCount(){
    return (matriz[0].length)-1;
}
    
    
    public void submit(){
    
    }
    public int[][] getMatriz() {
        prepararProblema();
        return matriz;
    }
    
    /**
     * Creates a new instance of Sudoku
     */
    public Sudoku() {
    }
    public Sudoku(int tamanho){
        
        this.tamanho = tamanho;
    }
    
    
    public void prepararProblema() {
        tamanho = 3;
        int val = 0;
        matriz = new int[tamanho*tamanho][tamanho*tamanho]; // default 0 vals
        for (int i = 0; i < tamanho*tamanho; ++i) {
            for (int j = 0; j < tamanho*tamanho; j++) {    
            matriz[i][j] = val;
            } 
        }   
        matriz[5][8] = 5;

    }
    
    boolean legal(int i, int j, int val, int[][] cells) {
        
        for (int k = 0; k < tamanho*tamanho; ++k)  // row
            if (val == cells[k][j])
                return false;

        for (int k = 0; k < tamanho*tamanho; ++k) // col
            if (val == cells[i][k])
                return false;

        int boxRowOffset = (i / tamanho)*tamanho;
        int boxColOffset = (j / tamanho)*tamanho;
        for (int k = 0; k < tamanho; ++k) // box
            for (int m = 0; m < tamanho; ++m)
                if (val == cells[boxRowOffset+k][boxColOffset+m])
                    return false;

        return true; // no violations, so it's legal
    }
    
        boolean solve(int i, int j) {
        if (i == tamanho*tamanho) {
            i = 0;
            if (++j == tamanho*tamanho)
                return true;
        }
        if (matriz[i][j] != 0){  // skip filled cells
            System.out.println("ddddadas");
            return solve(i+1,j);
            
        }

        for (int val = 1; val <= tamanho*tamanho; ++val) {
            if (legal(i,j,val,matriz)) {
                matriz[i][j] = val;
//                writeMatrix();
                if (solve(i+1,j))
                    return true;
            }
        }
        matriz[i][j] = 0; // reset on backtrack
        return false;
    }
    
        void writeMatrix() {
        for (int i = 0; i < tamanho*tamanho; ++i) {
            if (i % tamanho == 0)
                System.out.println(" -----------------------");
            for (int j = 0; j < tamanho*tamanho; ++j) {
                if (j % tamanho == 0) System.out.print("| ");
                System.out.print(matriz[i][j] == 0
                                 ? " "
                                 : Integer.toString(matriz[i][j]));

                System.out.print(' ');
            }
            System.out.println("|");
        }
        System.out.println(" -----------------------");
    }
        
    public static void main(String[] args) {
        Sudoku teste = new Sudoku(5);
        teste.prepararProblema();
        teste.writeMatrix();
        if (teste.solve(0,0))    // solves in place
            teste.writeMatrix();
        else
            System.out.println("Sem Resposta");
    }
}
